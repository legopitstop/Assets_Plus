# CHANGELOG v1.1.0
## General
- Added some atlas names