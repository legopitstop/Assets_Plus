# Assets Plus

This is a resrouce pack library that adds all the vanilla minecraft block ids use better ID's to use these just add the `minecraft` namespace before the texture for example: `minecraft:lime_concrete` to use the lime concrete texture. This resrouce pack also adds a few new textures like java edition's debug textures

## Note

This resrouce pack libarary does not contain the vanilla minecraft assets. It will use vanilla minecraft, or the highest tier resoruce pack, textures.

## Table of Contents

- [Dependencies](#dependencies)
- [Planned features](#planned-features)
  - [Block Textures](/Block%20Textures.md)
  - [Item Textures](/Item%20Textures.md)
- [Models](/Models.md)

## Dependencies

In your Behavior packs dependencies append the following code:

```json
{
    "uuid": "c86dd7d9-e84e-456f-a84f-1993e353da4c",
    "version": [1, 0, 0]
}
```

## Planned Features

- Common block models, stairs, slabs, torches, etc
