# Changelog

## v1.2.0 - 2022-6-23

### Added

- Added some atlas names
- Added block models. see [Models](docs/Models.md) for more.
- Added 1.19 block textures. see [Block Textures](docs/Block%20Textures.md) for more.
- Added item textures. see [Item Textures](docs/Item%20Textures.md) for more.
